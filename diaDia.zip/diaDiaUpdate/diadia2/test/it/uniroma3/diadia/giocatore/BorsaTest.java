package it.uniroma3.diadia.giocatore;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.attrezzi.Attrezzo;
/**
 * classe di test della classe Borsa
 * 
 * @author Xadri
 *
 */
public class BorsaTest {

	private Borsa borsaVuota;
	private Borsa borsaPiena;
	private Attrezzo spranga;
	private Attrezzo erFero;

	
	@Before
	public  void setUp() {
		borsaPiena= new Borsa();
		borsaVuota= new Borsa();
		this.spranga= new Attrezzo("spranga", 10);
		this.erFero= new Attrezzo("erFero", 4);
		this.borsaPiena.addAttrezzo(spranga);

		
	}
	
	

	@Test
	public void testRemoveAttrezzoBorsaVuota() {
		assertEquals("Errore, non c'� la spranga", false , this.borsaVuota.removeAttrezzo("spranga"));
	}


	
	@Test
	public void testRemoveAttrezzoBorsaPiena() {
		assertEquals("Errore, l'attrezzo � presente e lo zaino � pieno", true , this.borsaPiena.removeAttrezzo("spranga"));

	}
	
	@Test
	public void testRemoveAttrezzoBorsaPienaAttrezzoNonPresente() {
		assertEquals("Errore, l'attrezzo � presente e lo zaino � pieno", false , this.borsaPiena.removeAttrezzo("erFero"));

	}
	/**
	 * Test metodo addAttrezzo
	 */

	@Test
	public void testAddAttrezzoBorsaPiena() {

		assertEquals("Errore, non avrebbe potuto aggiungerlo", false , this.borsaPiena.addAttrezzo(erFero));

	}

	@Test
	public void testAddAttrezzoBorseVuota() {
		assertEquals("Errore, avrebbe dovuto aggiungerlo", true, this.borsaVuota.addAttrezzo(erFero));

	}

	@Test
	public void testAddAttrezzoSenzaAttrezzo() {
		assertEquals("Errore, non hai aggiunto nessun attrezzo", false, this.borsaVuota.addAttrezzo(null));
	}


	/**
	 * Test metodo hasAttrezzo
	 */

	@Test
	public void testHasAttrezzoConAttrezzoPresente() {
		assertEquals("Errore, l'attrezzo � presente", true, this.borsaPiena.hasAttrezzo("spranga"));
	}

	@Test
	public void testHasAttrezzoConAttrezzoNonPresente() {
		assertEquals("Errore, l'attrezzo non � presente", false, this.borsaPiena.hasAttrezzo("joint"));
	}
	@Test
	public void testHasAttrezzoConAttrezzoNonPresenteBis() {
		assertEquals("Errore, non ci sono proprio attrezzi qui", false, this.borsaVuota.hasAttrezzo("joint"));
	}

	@Test
	public void testHasAttrezzoConAttrezzoSconosciuto() {
		assertEquals("Errore, l'attrezzo non esiste proprio", false, this.borsaPiena.hasAttrezzo("cravatta"));


	}

	/**
	 * Test metodo getAttrezzo
	 */

	@Test
	public void testGetAttrezzoConAttrezzoPresente() {
		assertEquals("Errore, l'attrezzo � presente", spranga , this.borsaPiena.getAttrezzo("spranga"));
	}

	@Test
	public void testGetAttrezzoConAttrezzoNonPresente() {
		assertEquals("Errore, l'attrezzo non � presente", null, this.borsaPiena.getAttrezzo("joint"));
	}
	@Test
	public void testGetAttrezzoConAttrezzoNonPresenteBis() {
		assertEquals("Errore, non ci sono proprio attrezzi qui", null, this.borsaVuota.getAttrezzo("joint"));
	}


	@Test
	public void testGetAttrezzoConAttrezzoSconosciuto() {
		assertEquals("Errore, l'attrezzo non esiste proprio", null , this.borsaPiena.getAttrezzo("cravatta"));


	}
	
}
