package it.uniroma3.diadia.comandi;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ComandoVaiTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testEsegui() {
		fail("Not yet implemented");
	}

}
